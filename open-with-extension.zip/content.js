//*[@id=":R75ab:"]/span/span[2]
// Content script to add "Open" button to GitHub repositories

//*[@id=":R75ab:"]

let extensionSettings = {
  serverUrl: "http://localhost:4040",
  githubToken: "",
};

// Load settings from storage
chrome.storage.sync.get(["serverUrl", "githubToken"], function (result) {
  extensionSettings.serverUrl = result.serverUrl || "http://localhost:4040";
  extensionSettings.githubToken = result.githubToken || "";
});

// Listen for settings updates from popup
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "updateSettings") {
    extensionSettings.serverUrl = request.serverUrl;
    extensionSettings.githubToken = request.githubToken;

    // Update existing button if present
    const existingButton = document.querySelector("#code-server-open-btn");
    if (existingButton) {
      updateButtonUrl(existingButton);
    }
  }
});

function addOpenButton() {
  console.log("Attempting to add button...");

  const codeBtn = document.querySelector('button[data-variant="primary"]');
  const buttonContainer = codeBtn.parentElement;

  // Use the specific container selector you provided
  // const buttonContainer = document.querySelector("#repo-content-pjax-container > div > div > div > div.Layout-main > react-partial > div > div > div.OverviewContent-module__Box_1--RhaEy > div.OverviewContent-module__Box_6--wV7Tw");

  if (!buttonContainer) {
    console.log("Button container not found, trying fallback selector...");
    // Fallback to the original selector
    const fallbackContainer = document.querySelector(
      '[data-testid="repository-header-element"] .d-flex'
    );
    if (!fallbackContainer) {
      console.log("No suitable container found");
      return;
    }
    // Use fallback container
    return addButtonToContainer(fallbackContainer);
  }

  console.log("Found button container:", buttonContainer);
  return addButtonToContainer(buttonContainer);
}

function addButtonToContainer(container) {
  // Check if button already exists
  if (document.querySelector("#code-server-open-btn")) {
    console.log("Button already exists");
    return;
  }

  // Get repository URL
  const currentUrl = window.location.href;
  const repoMatch = currentUrl.match(/github\.com\/([^\/]+\/[^\/]+)/);

  if (!repoMatch) {
    console.log("Not a repository page");
    return;
  }

  const repoPath = repoMatch[1];
  const isPrivate =
    document.querySelector('[data-testid="private-icon"]') !== null;

  // Determine clone URL based on repository visibility
  let cloneUrl;
  if (isPrivate) {
    // For private repos, prefer SSH but also support HTTPS
    cloneUrl = `git@github.com:${repoPath}.git`;
  } else {
    // For public repos, use HTTPS
    cloneUrl = `https://github.com/${repoPath}.git`;
  }

  console.log("Creating button for repo:", repoPath, "Clone URL:", cloneUrl);

  // Create the "Open" button
  const openButton = document.createElement("a");
  openButton.id = "code-server-open-btn";
  openButton.target = "_blank";
  openButton.rel = "noopener noreferrer";
  openButton.className = "btn btn-sm btn-primary";

  // Set initial URL
  updateButtonUrl(openButton, cloneUrl);

  // Button content with icon
  openButton.innerHTML = `
    <svg class="octicon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
      <path d="M1.75 1A1.75 1.75 0 0 0 0 2.75v10.5C0 14.216.784 15 1.75 15h12.5A1.75 1.75 0 0 0 16 13.25V2.75A1.75 1.75 0 0 0 14.25 1H1.75zM1.5 2.75a.25.25 0 0 1 .25-.25h12.5a.25.25 0 0 1 .25.25v10.5a.25.25 0 0 1-.25.25H1.75a.25.25 0 0 1-.25-.25V2.75z"/>
      <path d="M7.25 8a.75.75 0 0 1-.22-.53V4.75a.75.75 0 0 1 1.5 0V6.44l1.72-1.72a.75.75 0 1 1 1.06 1.06L8.56 8.53a.75.75 0 0 1-1.31-.53z"/>
    </svg>
    Open
  `;

  // Add some spacing and append to the container
  openButton.style.marginLeft = "8px";
  container.appendChild(openButton);

  console.log("Button added successfully to container");

  // Add click event for analytics/feedback
  openButton.addEventListener("click", function () {
    console.log("Opening repository in Code Server:", cloneUrl);

    // Show a brief notification
    showNotification("Opening in Code Server...", "success");
  });
}

function updateButtonUrl(button, cloneUrl) {
  let url = `${extensionSettings.serverUrl}/clone?repo=${encodeURIComponent(
    cloneUrl
  )}`;

  // Add token if available and using HTTPS
  if (extensionSettings.githubToken && cloneUrl.startsWith("https://")) {
    url += `&token=${encodeURIComponent(extensionSettings.githubToken)}`;
  }

  button.href = url;
}

function showNotification(message, type = "info") {
  // Create notification element
  const notification = document.createElement("div");
  notification.className = `code-server-notification ${type}`;
  notification.textContent = message;

  // Add to page
  document.body.appendChild(notification);

  // Remove after 3 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.parentNode.removeChild(notification);
    }
  }, 3000);
}

// Run when page loads
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", addOpenButton);
} else {
  addOpenButton();
}

// Also run when navigating (GitHub uses AJAX navigation)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    console.log("URL changed to:", url);
    // Try multiple times with increasing delays for dynamic content
    setTimeout(addOpenButton, 100);
    setTimeout(addOpenButton, 500);
    setTimeout(addOpenButton, 1000);
  }
}).observe(document, { subtree: true, childList: true });

// Also try to add button when specific elements are added to the DOM
const targetObserver = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.type === "childList") {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          // Check if the added node contains our target container
          if (
            node.querySelector &&
            (node.querySelector(".OverviewContent-module__Box_6--wV7Tw") ||
              node.querySelector('[data-testid="repository-header-element"]'))
          ) {
            console.log(
              "Target container added to DOM, attempting to add button"
            );
            setTimeout(addOpenButton, 100);
          }
        }
      });
    }
  });
});

targetObserver.observe(document.body, {
  childList: true,
  subtree: true,
});
