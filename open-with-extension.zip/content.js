//*[@id=":R75ab:"]/span/span[2]
// Content script to add "Open" button to GitHub repositories

//*[@id=":R75ab:"]

let extensionSettings = {
    serverUrl: "http://localhost:4040",
    githubToken: "",
};

// Load settings from storage
chrome.storage.sync.get(["serverUrl", "githubToken"], function (result) {
    extensionSettings.serverUrl = result.serverUrl || "http://localhost:4040";
    extensionSettings.githubToken = result.githubToken || "";
});

// Listen for settings updates from popup
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.action === "updateSettings") {
        extensionSettings.serverUrl = request.serverUrl;
        extensionSettings.githubToken = request.githubToken;

        // Update existing button if present
        const existingButton = document.querySelector("#code-server-open-btn");
        if (existingButton) {
            updateButtonUrl(existingButton);
        }
    }
});

function addOpenButton() {
    console.log("Attempting to add button...");

    const codeBtn = document.querySelector('button[data-variant="primary"]');
    const buttonContainer = codeBtn.parentElement;

    // Use the specific container selector you provided
    // const buttonContainer = document.querySelector("#repo-content-pjax-container > div > div > div > div.Layout-main > react-partial > div > div > div.OverviewContent-module__Box_1--RhaEy > div.OverviewContent-module__Box_6--wV7Tw");

    if (!buttonContainer) {
        console.log("Button container not found, trying fallback selector...");
        // Fallback to the original selector
        const fallbackContainer = document.querySelector(
            '[data-testid="repository-header-element"] .d-flex'
        );
        if (!fallbackContainer) {
            console.log("No suitable container found");
            return;
        }
        // Use fallback container
        return addButtonToContainer(fallbackContainer);
    }

    console.log("Found button container:", buttonContainer);
    return addButtonToContainer(buttonContainer);
}

function addButtonToContainer(container) {
    // Check if button already exists
    if (document.querySelector("#code-server-open-btn")) {
        console.log("Button already exists");
        return;
    }

    // Get repository URL
    const currentUrl = window.location.href;
    const repoMatch = currentUrl.match(/github\.com\/([^\/]+\/[^\/]+)/);

    if (!repoMatch) {
        console.log("Not a repository page");
        return;
    }

    const repoPath = repoMatch[1];
    const isPrivate =
        document.querySelector('[data-testid="private-icon"]') !== null;

    // Determine clone URL based on repository visibility
    let cloneUrl;
    if (isPrivate) {
        // For private repos, prefer SSH but also support HTTPS
        cloneUrl = `git@github.com:${repoPath}.git`;
    } else {
        // For public repos, use HTTPS
        cloneUrl = `https://github.com/${repoPath}.git`;
    }

    console.log("Creating button for repo:", repoPath, "Clone URL:", cloneUrl);

    // Create the "Open" button
    const openButton = document.createElement("a");
    openButton.id = "code-server-open-btn";
    openButton.target = "_blank";
    openButton.rel = "noopener noreferrer";
    openButton.className = "btn btn-sm btn-primary";

    // Set initial URL
    updateButtonUrl(openButton, cloneUrl);

    // Button content with icon
    openButton.innerHTML = `
       <svg fill="#ffffff" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" stroke="#ffffff"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M30.865 3.448l-6.583-3.167c-0.766-0.37-1.677-0.214-2.276 0.385l-12.609 11.505-5.495-4.167c-0.51-0.391-1.229-0.359-1.703 0.073l-1.76 1.604c-0.583 0.526-0.583 1.443-0.005 1.969l4.766 4.349-4.766 4.349c-0.578 0.526-0.578 1.443 0.005 1.969l1.76 1.604c0.479 0.432 1.193 0.464 1.703 0.073l5.495-4.172 12.615 11.51c0.594 0.599 1.505 0.755 2.271 0.385l6.589-3.172c0.693-0.333 1.13-1.031 1.13-1.802v-21.495c0-0.766-0.443-1.469-1.135-1.802zM24.005 23.266l-9.573-7.266 9.573-7.266z"></path> </g></svg>
    Open
  `;

    // Add some spacing and append to the container
    openButton.style.marginLeft = "8px";
    container.appendChild(openButton);

    console.log("Button added successfully to container");

    // Add click event for analytics/feedback
    openButton.addEventListener("click", function () {
        console.log("Opening repository in Code Server:", cloneUrl);

        // Show a brief notification
        showNotification("Opening in Code Server...", "success");
    });
}

function updateButtonUrl(button, cloneUrl) {
    let url = `${extensionSettings.serverUrl}/clone?repo=${encodeURIComponent(
        cloneUrl
    )}`;

    // Add token if available and using HTTPS
    if (extensionSettings.githubToken && cloneUrl.startsWith("https://")) {
        url += `&token=${encodeURIComponent(extensionSettings.githubToken)}`;
    }

    button.href = url;
}

function showNotification(message, type = "info") {
    // Create notification element
    const notification = document.createElement("div");
    notification.className = `code-server-notification ${type}`;
    notification.textContent = message;

    // Add to page
    document.body.appendChild(notification);

    // Remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}

// Run when page loads
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addOpenButton);
} else {
    addOpenButton();
}

// Also run when navigating (GitHub uses AJAX navigation)
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        console.log("URL changed to:", url);
        // Try multiple times with increasing delays for dynamic content
        setTimeout(addOpenButton, 100);
        setTimeout(addOpenButton, 500);
        setTimeout(addOpenButton, 1000);
    }
}).observe(document, { subtree: true, childList: true });

// Also try to add button when specific elements are added to the DOM
const targetObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.type === "childList") {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    // Check if the added node contains our target container
                    if (
                        node.querySelector &&
                        (node.querySelector(
                            ".OverviewContent-module__Box_6--wV7Tw"
                        ) ||
                            node.querySelector(
                                '[data-testid="repository-header-element"]'
                            ))
                    ) {
                        console.log(
                            "Target container added to DOM, attempting to add button"
                        );
                        setTimeout(addOpenButton, 100);
                    }
                }
            });
        }
    });
});

targetObserver.observe(document.body, {
    childList: true,
    subtree: true,
});
