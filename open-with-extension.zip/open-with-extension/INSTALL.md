# Installation Guide

## Quick Install

1. **Open Chrome Extensions**

   ```
   chrome://extensions/
   ```

2. **Enable Developer Mode**

   - Toggle "Developer mode" in the top right

3. **Load Extension**

   - Click "Load unpacked"
   - Select the `open-with-extension` folder
   - Extension should appear in your list

4. **Configure (Optional)**
   - Click the extension icon in toolbar
   - Set your Code Server URL (default: `http://localhost:4040`)
   - Add GitHub token for private repos

## Usage

1. Go to any GitHub repository
2. Look for the green "Open" button next to the Code button
3. Click to open in your Code Server

## Troubleshooting

### Button not showing?

- Make sure you're on a repository page (not profile/issues)
- Refresh the page
- Check if extension is enabled

### Clone not working?

- Verify Code Server is running at configured URL
- Check authentication (SSH keys or GitHub token)
- Test the clone URL manually

## Uninstall

1. Go to `chrome://extensions/`
2. Find "Open with Code Server"
3. Click "Remove"
