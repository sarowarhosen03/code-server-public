# Code Server Chrome Extension

A Chrome extension that adds an "Open" button to GitHub repository pages, allowing you to quickly open repositories in your Code Server instance.

![Extension Popup](screenshot-popup.png)

## Features

- 🚀 **One-click repository opening** - Adds an "Open" button next to GitHub's Code button
- 🔐 **Private repository support** - Works with both SSH keys and Personal Access Tokens
- ⚙️ **Configurable** - Set your Code Server URL and GitHub token via extension popup
- 🎨 **GitHub-native styling** - Button matches GitHub's design language
- 📱 **Responsive** - Works on desktop and mobile GitHub
- 🌙 **Dark theme** - Beautiful dark popup interface

## Installation

### Method 1: Load Unpacked (Development)

1. **Open Chrome Extensions**

   - Go to `chrome://extensions/`
   - Enable "Developer mode" (top right toggle)

2. **Load the Extension**

   - Click "Load unpacked"
   - Select the `open-with-extension` folder
   - The extension should now appear in your extensions list

3. **Configure Settings**

   - Click the extension icon in the toolbar to open the dark-themed popup
   - Set your Code Server URL (default: `http://localhost:3009`)
   - Optionally add your GitHub token for private repos

   ![Extension Configuration](screenshot-popup.png)

### Method 2: Create Icons (Optional)

If you want custom icons:

1. Open `icons/create-icons.html` in your browser
2. It will automatically download the icon files
3. Save them as `icon16.png`, `icon48.png`, and `icon128.png` in the `icons/` folder

## Usage

1. **Navigate to any GitHub repository**
2. **Look for the green "Open" button** next to the Code button
3. **Click to open** the repository in your Code Server

The extension automatically:

- Detects if the repository is private/public
- Uses appropriate clone URL (SSH for private, HTTPS for public)
- Opens the clone URL in a new tab

## Configuration

### Extension Settings

Click the extension icon to configure:

- **Code Server URL**: Where your clone server is running (e.g., `http://localhost:3009`)
- **GitHub Token**: Personal Access Token for private repositories (optional)

### Supported Repository Types

- ✅ **Public repositories** - Uses HTTPS clone URLs
- ✅ **Private repositories** - Uses SSH clone URLs (requires SSH keys)
- ✅ **Private repositories with token** - Uses HTTPS with authentication

## How It Works

1. **Content Script** (`content.js`) runs on GitHub pages
2. **Detects repository pages** and adds the "Open" button
3. **Generates clone URL** based on repository visibility
4. **Opens Code Server** with the appropriate clone command

## File Structure

```
open-with-extension/
├── manifest.json          # Extension configuration
├── content.js            # Main script that adds the button
├── styles.css            # Button and notification styles
├── popup.html            # Settings popup interface
├── popup.js              # Settings popup logic
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md             # This file
```

## Customization

### Change Button Appearance

Edit `styles.css` to modify:

- Button colors and styling
- Hover effects
- Mobile responsiveness

### Modify Button Behavior

Edit `content.js` to:

- Change button placement
- Add custom logic for different repository types
- Modify clone URL generation

### Add New Features

- Support for other Git hosting services (GitLab, Bitbucket)
- Custom keyboard shortcuts
- Repository bookmarking
- Integration with other development tools

## Troubleshooting

### Button Not Appearing

1. **Check if you're on a repository page** (not user profile, issues, etc.)
2. **Refresh the page** after installing the extension
3. **Check browser console** for any JavaScript errors

### Clone Not Working

1. **Verify Code Server is running** at the configured URL
2. **Check authentication** (SSH keys or GitHub token)
3. **Test clone URL manually** in your browser

### Private Repository Issues

1. **For SSH**: Ensure SSH keys are properly configured
2. **For HTTPS**: Add your GitHub Personal Access Token in extension settings

## Development

### Making Changes

1. Edit the extension files
2. Go to `chrome://extensions/`
3. Click the refresh icon on your extension
4. Test on GitHub repository pages

### Debugging

- Use Chrome DevTools on GitHub pages to debug content script
- Check extension popup for settings issues
- Monitor network requests for clone server communication

## Security Notes

- Extension only runs on GitHub.com domains
- GitHub tokens are stored locally in Chrome's sync storage
- No data is sent to external servers (except your Code Server)
- All communication is between GitHub, your browser, and your local Code Server

## License

MIT License - feel free to modify and distribute!
