// Popup script for extension settings

document.addEventListener('DOMContentLoaded', function () {
    const serverUrlInput = document.getElementById('server-url');
    const githubTokenInput = document.getElementById('github-token');
    const statusDiv = document.getElementById('status');
    const resetBtn = document.getElementById('reset-btn');

    // Load saved settings
    chrome.storage.sync.get(['serverUrl', 'githubToken'], function (result) {
        serverUrlInput.value = result.serverUrl || 'http://localhost:4040';
        githubTokenInput.value = result.githubToken || '';
    });

    // Save settings when changed
    function saveSettings() {
        const serverUrl = serverUrlInput.value.trim();
        const githubToken = githubTokenInput.value.trim();

        chrome.storage.sync.set({
            serverUrl: serverUrl,
            githubToken: githubToken
        }, function () {
            showStatus('Settings saved!', 'success');

            // Send message to content script to update settings
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs[0] && tabs[0].url.includes('github.com')) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'updateSettings',
                        serverUrl: serverUrl,
                        githubToken: githubToken
                    });
                }
            });
        });
    }

    function showStatus(message, type) {
        statusDiv.textContent = message;
        statusDiv.className = `status ${type}`;
        statusDiv.style.display = 'block';

        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }

    // Auto-save on input change
    serverUrlInput.addEventListener('input', saveSettings);
    githubTokenInput.addEventListener('input', saveSettings);

    // Validate server URL format
    serverUrlInput.addEventListener('blur', function () {
        const url = serverUrlInput.value.trim();
        if (url && !url.match(/^https?:\/\/.+/)) {
            showStatus('Please enter a valid URL (e.g., http://localhost:4040)', 'error');
        }
    });

    // Reset settings to defaults
    function resetSettings() {
        const defaultSettings = {
            serverUrl: 'http://localhost:4040',
            githubToken: ''
        };

        // Update UI
        serverUrlInput.value = defaultSettings.serverUrl;
        githubTokenInput.value = defaultSettings.githubToken;

        // Save to storage
        chrome.storage.sync.set(defaultSettings, function () {
            showStatus('Settings reset to defaults!', 'success');

            // Send message to content script to update settings
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs[0] && tabs[0].url.includes('github.com')) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'updateSettings',
                        serverUrl: defaultSettings.serverUrl,
                        githubToken: defaultSettings.githubToken
                    });
                }
            });
        });
    }

    // Reset button click handler
    resetBtn.addEventListener('click', function () {
        // Add confirmation to prevent accidental resets
        resetSettings();

    });
});